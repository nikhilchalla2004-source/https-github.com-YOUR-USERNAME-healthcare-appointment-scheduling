# Healthcare Appointment Scheduling

**Project title:** A Knowledge-Based Probabilistic Framework for Enhancing Healthcare Appointment Scheduling

A beginner-friendly academic prototype built with Python, Flask, HTML, CSS, and SQLite.

## Features

- Book appointments with sample doctors.
- Choose a date and time slot.
- Prevent duplicate bookings for the same doctor, date, and time.
- View upcoming appointments and filter by doctor.
- Cancel appointments.
- Show a simple rule-based appointment delay-risk estimate.

## Requirements

- Python 3.10 or newer
- pip

## Run locally

1. Download and extract this project folder.
2. Open Command Prompt or a terminal in the extracted folder.
3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   python app.py
   ```

5. Open http://127.0.0.1:5000 in your browser.

The SQLite database file (`appointments.db`) is created automatically when the app starts.

## Project structure

```text
healthcare-appointment-scheduling/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Important limitation

The delay-risk estimate is an illustrative rule-based score used to demonstrate the project concept. It is **not** based on trained data and is **not clinically validated**. Do not use this prototype for real patient care or enter real patient or sensitive medical information. For a research-grade probabilistic model, use suitable de-identified data, define measurable outcomes, validate the model, and review privacy and security requirements.

## Suggested future improvements

- Add login and role-based access for patients and administrators.
- Add notifications and appointment reminders.
- Use de-identified historical data to train and evaluate a probabilistic model.
- Add tests, audit logging, and stronger production security before any real deployment.
