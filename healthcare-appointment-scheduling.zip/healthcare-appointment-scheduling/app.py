from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import datetime, date

app = Flask(__name__)
app.secret_key = "replace-this-with-a-random-secret-key"
DB_PATH = Path(__file__).with_name("appointments.db")

DOCTORS = [
    {"id": 1, "name": "Dr. Ananya Rao", "specialty": "General Physician"},
    {"id": 2, "name": "Dr. Rahul Sharma", "specialty": "Cardiology"},
    {"id": 3, "name": "Dr. Priya Reddy", "specialty": "Dermatology"},
]
TIME_SLOTS = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
              "14:00", "14:30", "15:00", "15:30", "16:00", "16:30"]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_name TEXT NOT NULL,
                patient_email TEXT NOT NULL,
                doctor_id INTEGER NOT NULL,
                appointment_date TEXT NOT NULL,
                appointment_time TEXT NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(doctor_id, appointment_date, appointment_time)
            )
        """)


def estimate_delay_probability(appointment_date, appointment_time):
    """
    Educational demonstration only. This is a transparent rule-based score,
    NOT a trained or clinically validated prediction model.
    """
    probability = 0.15
    hour = int(appointment_time.split(":")[0])
    if hour in (10, 11, 15):
        probability += 0.15
    if date.fromisoformat(appointment_date).weekday() == 0:
        probability += 0.10  # Monday
    if hour >= 15:
        probability += 0.10
    return min(probability, 0.75)


@app.route("/", methods=["GET"])
def index():
    selected_date = request.args.get("date", date.today().isoformat())
    selected_doctor = request.args.get("doctor", "")
    conn = get_db()
    query = """
        SELECT a.*, d.name AS doctor_name, d.specialty
        FROM appointments a
        JOIN (SELECT 1 AS id, 'Dr. Ananya Rao' AS name, 'General Physician' AS specialty
              UNION ALL SELECT 2, 'Dr. Rahul Sharma', 'Cardiology'
              UNION ALL SELECT 3, 'Dr. Priya Reddy', 'Dermatology') d
        ON a.doctor_id = d.id
        WHERE a.appointment_date >= ?
    """
    params = [date.today().isoformat()]
    if selected_doctor:
        query += " AND a.doctor_id = ?"
        params.append(selected_doctor)
    query += " ORDER BY a.appointment_date, a.appointment_time LIMIT 20"
    appointments = conn.execute(query, params).fetchall()
    conn.close()

    booked_rows = []
    conn = get_db()
    if selected_date:
        booked_rows = conn.execute(
            "SELECT doctor_id, appointment_time FROM appointments WHERE appointment_date = ?",
            (selected_date,)
        ).fetchall()
    conn.close()
    booked = {(row["doctor_id"], row["appointment_time"]) for row in booked_rows}
    return render_template(
        "index.html",
        doctors=DOCTORS,
        time_slots=TIME_SLOTS,
        appointments=appointments,
        selected_date=selected_date,
        selected_doctor=selected_doctor,
        booked=booked,
        today=date.today().isoformat()
    )


@app.route("/book", methods=["POST"])
def book():
    patient_name = request.form.get("patient_name", "").strip()
    patient_email = request.form.get("patient_email", "").strip()
    doctor_id = request.form.get("doctor_id", "").strip()
    appointment_date = request.form.get("appointment_date", "").strip()
    appointment_time = request.form.get("appointment_time", "").strip()
    reason = request.form.get("reason", "").strip()

    if not all([patient_name, patient_email, doctor_id, appointment_date, appointment_time, reason]):
        flash("Please complete every field before booking.", "error")
        return redirect(url_for("index"))

    try:
        doctor_id = int(doctor_id)
    except ValueError:
        flash("Please choose a valid doctor.", "error")
        return redirect(url_for("index"))

    if doctor_id not in [d["id"] for d in DOCTORS]:
        flash("Please choose a valid doctor.", "error")
        return redirect(url_for("index"))
    if appointment_time not in TIME_SLOTS:
        flash("Please choose a valid time slot.", "error")
        return redirect(url_for("index"))
    try:
        chosen_date = date.fromisoformat(appointment_date)
    except ValueError:
        flash("Please choose a valid appointment date.", "error")
        return redirect(url_for("index"))
    if chosen_date < date.today():
        flash("Appointments cannot be booked in the past.", "error")
        return redirect(url_for("index"))
    if "@" not in patient_email or "." not in patient_email.rsplit("@", 1)[-1]:
        flash("Please enter a valid email address.", "error")
        return redirect(url_for("index"))

    probability = estimate_delay_probability(appointment_date, appointment_time)
    try:
        with get_db() as conn:
            conn.execute("""
                INSERT INTO appointments
                (patient_name, patient_email, doctor_id, appointment_date,
                 appointment_time, reason, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (patient_name, patient_email, doctor_id, appointment_date,
                  appointment_time, reason, datetime.now().isoformat(timespec="seconds")))
        flash(f"Appointment booked successfully. Demonstration delay-risk estimate: {probability:.0%}.", "success")
    except sqlite3.IntegrityError:
        flash("That doctor and time slot are already booked. Please choose another slot.", "error")
    return redirect(url_for("index", date=appointment_date))


@app.route("/cancel/<int:appointment_id>", methods=["POST"])
def cancel(appointment_id):
    with get_db() as conn:
        cursor = conn.execute("DELETE FROM appointments WHERE id = ?", (appointment_id,))
    if cursor.rowcount:
        flash("Appointment cancelled.", "success")
    else:
        flash("Appointment was not found.", "error")
    return redirect(url_for("index"))


@app.route("/health")
def health():
    return {"status": "ok", "project": "Healthcare Appointment Scheduling"}


init_db()

if __name__ == "__main__":
    app.run(debug=True)
